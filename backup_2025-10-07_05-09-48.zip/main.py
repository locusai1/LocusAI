import os
from core.ai import process_message
from core.knowledge import load_business_data
from core.logger import log_interaction
from core.db import init_db, get_or_create_business, create_session
from adapters import local as io   # swap to adapters.twilio for production

def list_businesses():
    files = os.listdir("businesses")
    businesses = [f.replace(".json", "").replace("_", " ") for f in files if f.endswith(".json")]
    return businesses

def run():
    # Initialize database/tables
    init_db()

    # List available businesses from /businesses
    businesses = list_businesses()
    print("Available businesses:")
    for b in businesses:
        print(" -", b)

    # Pick one and load its JSON profile
    business_name_input = input("\nWhich business do you want to load? ").strip()
    business_data = load_business_data(business_name_input)

    # Ensure business exists in DB and start a session
    business_id, _slug = get_or_create_business(business_data["name"])
    session_id = create_session(business_id)

    print(f"\nReceptionist for {business_data['name']} is now running...\n")
    state = {}

    while True:
        user_input = io.get_user_input()
        response = process_message(user_input, business_data, state)
        io.send_response(response)

        # Log both sides to SQLite
        log_interaction(session_id, user_input, response)

if __name__ == "__main__":
    run()


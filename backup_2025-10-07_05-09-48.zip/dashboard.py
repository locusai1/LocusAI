from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3, os, json
from core.knowledge import load_business_data

DB_PATH = "receptionist.db"

app = Flask(__name__, template_folder="templates")
app.secret_key = "supersecret-change-me"  # ⚠️ change for production


# --- DB Helper ---
def get_conn():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


# --- Routes ---

@app.route("/test")
def test():
    return "HELLO FROM FLASK"


@app.route("/")
def home():
    if "user" in session:
        return redirect(url_for("businesses"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    print("HIT /login", flush=True)
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == "admin" and password == "admin":   # demo only
            session["user"] = username
            return redirect(url_for("businesses"))
        return "Invalid credentials", 401
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))


@app.route("/businesses")
def businesses():
    if "user" not in session:
        return redirect(url_for("login"))
    with get_conn() as con:
        rows = con.execute("SELECT id, name FROM businesses ORDER BY name").fetchall()
    return render_template("businesses.html", businesses=rows)


@app.route("/business/<int:business_id>")
def business_dashboard(business_id):
    if "user" not in session:
        return redirect(url_for("login"))

    with get_conn() as con:
        business = con.execute("SELECT * FROM businesses WHERE id = ?", (business_id,)).fetchone()
        sessions = con.execute(
            "SELECT * FROM sessions WHERE business_id = ? ORDER BY started_at DESC",
            (business_id,)
        ).fetchall()
        messages = con.execute(
            """SELECT * FROM messages
               WHERE session_id IN (SELECT id FROM sessions WHERE business_id = ?)
               ORDER BY id DESC LIMIT 50""",
            (business_id,)
        ).fetchall()
        appointments = con.execute(
            "SELECT * FROM appointments WHERE business_id = ? ORDER BY created_at DESC",
            (business_id,)
        ).fetchall()

    # Load JSON info (fallback if not found)
    business_data = {"faqs": {}, "name": business["name"]}
    try:
        business_data = load_business_data(business["slug"])
    except Exception as e:
        print(f"Could not load JSON for business slug: {e}", flush=True)

    return render_template(
        "dashboard.html",
        business=business,
        sessions=sessions,
        messages=messages,
        appointments=appointments,
        business_data=business_data,
    )


@app.route("/business/<int:business_id>/edit", methods=["GET", "POST"])
def edit_business(business_id):
    if "user" not in session:
        return redirect(url_for("login"))

    with get_conn() as con:
        business = con.execute("SELECT * FROM businesses WHERE id = ?", (business_id,)).fetchone()

    json_path = os.path.join("businesses", f"{business['slug']}.json")

    if request.method == "POST":
        new_name = request.form.get("name")
        new_hours = request.form.get("hours")
        new_location = request.form.get("location")
        new_services = request.form.get("services")

        data = {
            "name": new_name,
            "faqs": {
                "what are your hours?": new_hours,
                "where are you located?": new_location,
                "what services do you offer?": new_services
            }
        }

        with open(json_path, "w") as f:
            json.dump(data, f, indent=2)

        return redirect(url_for("business_dashboard", business_id=business_id))

    if os.path.exists(json_path):
        with open(json_path, "r") as f:
            business_data = json.load(f)
    else:
        business_data = {"name": business["name"], "faqs": {}}

    return render_template("edit_business.html", business=business, business_data=business_data)


# --- Run App ---
if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)


import json
import os

def load_business_data(business_name):
    """
    Loads business data from a JSON file in /businesses.
    Converts spaces in business_name to underscores so filenames are safe.
    """
    safe_name = business_name.replace(" ", "_").lower()
    path = os.path.join("businesses", f"{safe_name}.json")
    if not os.path.exists(path):
        raise FileNotFoundError(f"No business profile found for '{business_name}' (expected {path})")
    with open(path, "r") as f:
        return json.load(f)

